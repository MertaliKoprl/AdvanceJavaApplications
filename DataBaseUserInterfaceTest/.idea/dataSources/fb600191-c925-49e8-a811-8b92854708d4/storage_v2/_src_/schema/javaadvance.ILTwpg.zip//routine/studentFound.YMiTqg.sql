create function studentFound(first varchar(25), last varchar(25)) returns int
begin
	declare result int;
	select count(*) into result
	from student
	where student.fName=first and 
		Student.lName=last;
return result;
end;

