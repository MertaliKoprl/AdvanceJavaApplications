create trigger StatueByRating
  after INSERT
  on ratingsforarticle
  for each row
  update articles As A
Set A.Statues='accepted' AND A.presentationPkey=submitarticle.ContactKey
where avg(ratingsforarticle.orginality)>7 AND 
      avg(ratingsforarticle.relevance)>7 AND 
      avg(ratingsforarticle.readability)>7 AND 
      avg(ratingsforarticle.tech_merit)>7;

