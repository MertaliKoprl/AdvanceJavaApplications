create trigger Current_Year
  before INSERT
  on instructorgivescourses
  for each row
  SET NEW.semester_year = YEAR(NOW());

